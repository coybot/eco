Yonder — NeurIPS 2026 Datasets and Benchmarks Submission
=========================================================

Contents
--------
yonder_paper.pdf       Main submission PDF (anonymized, 9-page body
                       + checklist + references + appendix/datasheet).

yonder.croissant.json  Croissant 1.0 metadata for the dataset.
                       Validated with mlcroissant: 0 errors, 0 warnings.
                       Includes RAI fields (limitations, biases, social
                       impact, sensitive info) and prov:wasGeneratedBy.

Dataset
-------
Hosted at: https://huggingface.co/datasets/astralhf/yonder
Reviewer sample (50 waypoints + semantics):
            https://huggingface.co/datasets/astralhf/yonder-sample
License:    CC-BY-NC 4.0
Size:       4.65M frames across 167 HSSD scenes, ~3.3 TB total.

Notes for reviewers
-------------------
- The Croissant JSON-LD is also accessible directly from the dataset
  repository at:
  https://huggingface.co/datasets/astralhf/yonder/resolve/main/yonder.croissant.json
- The reviewer sample (yonder-sample) contains one full scene
  (hssd-102343992) with 50 waypoint NPZs and matching semantics; it
  exercises every modality and is sufficient for evaluating the data
  loading and annotation pipeline without downloading the full ~3.3 TB.
