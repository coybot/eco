# Yonder — Anonymized Code & Eval Logs

Companion repository for the NeurIPS 2026 Evaluations & Datasets Track
submission "Yonder: A 4.65M-Frame Drone Navigation Dataset and the
Cross-Simulator Generalization Gap."

This repository contains the minimum needed for a reviewer to verify
the paper's central empirical claim: that across four detector
configurations evaluated in closed-loop in Isaac Sim, navigation success
does not separate by detector quality, even though the same fine-tuned
detector achieves a 9.7× higher offline mAP on Yonder's held-out split.

The dataset itself is hosted at:

    https://huggingface.co/datasets/astralhf/yonder

A reviewer-sized sample (one full HSSD scene, 50 waypoints with all
modalities and matching semantics, ~2 GB) is at:

    https://huggingface.co/datasets/astralhf/yonder-sample

## Contents

    load_yonder.py        Minimal loader that reads one waypoint NPZ
                          (12 yaws × all sensor modalities) and prints
                          the per-modality shapes/dtypes. Optionally
                          loads the matching semantics NPZ as well.

    reproduce_finding.py  Loads the closed-loop trial logs in
                          eval_logs/ and prints success rates per
                          configuration. The paper's "23-25%
                          convergence" claim corresponds to the
                          err<5m column.

    eval_logs/            ~1.5K closed-loop trial logs (JSONL, one
                          trial per line) split by patch state:

        phase4_pre_patch/         All four detector configurations,
                                  before the cross-simulator
                                  coordinate-frame patch.
        phase4_post_patch_zclamp/ FT+Safety after the z-clamp patch.
        phase4_post_patch_r17/    FT+Safety, second post-patch sweep.
        r18/                      Zero-shot ablation with/without
                                  exploration.

## Reproducing the headline finding

    python reproduce_finding.py

Expected output: `err<5m` success rate clusters at 20-25% across all
four detector configurations. The boolean `arrived` field uses a tighter
per-tier tolerance and gives 8-12% across the same configurations; both
metrics tell the same story (no separation by detector quality).

## Loading a Yonder waypoint

After downloading one NPZ from the HuggingFace dataset:

    python load_yonder.py path/to/wp0000.npz \\
        --semantics path/to/scene_wp0000_semantics.npz

Or programmatically:

    from load_yonder import load_waypoint, load_semantics
    wp = load_waypoint("wp0000.npz")
    print(wp["left_rgb"].shape)         # (12, 480, 640, 3) uint8
    print(wp["forward_depth"].shape)    # (12, 480, 640)     float16
    print(wp["lidar360"].shape)         # (1024, 16)         float32
    sem = load_semantics("hssd-102343992_wp0000_semantics.npz")
    print(sem.shape, sem.dtype)         # (12, 480, 640) uint16

## Trial-log schema

Each line in `eval_logs/**/*.jsonl` is one closed-loop trial:

    {
      "condition":         "gdino_zeroshot__safety_disabled",
      "env":               "warehouse",
      "task_id":           "warehouse_named_near",
      "difficulty_tier":   "3_named_near",
      "seed":              42,
      "command":           "fly to the kitchen sink",
      "ground_truth":      [x, y, z],
      "spawn_position":    [x, y, z],
      "spawn_to_gt_m":     <float>,
      "predicted_goal":    [x, y, z],
      "final_position":    [x, y, z],
      "final_error_m":     <float>,         # final position vs ground truth
      "arrived":           <bool>,           # tight per-tier success criterion
      "num_steps":         <int>,
      "collisions":        <int>,
      "collision_free":    <bool>,
      "fd_veto_count":     <int>,
      "detection_failures":<int>,
      "total_flight_time_s": <float>,
      "elapsed_s":         <float>,
      "trial_key":         "<env>/<task_id>/seed<N>",
      "...": "..."
    }

## License

Code: MIT (LICENSE file). Data: CC-BY-NC 4.0 (set on the HuggingFace
dataset). Trial logs in eval_logs/ are released under the same CC-BY-NC
license as the dataset.

## Out of scope for this release

The full closed-loop benchmark runner, the Habitat-Sim waypoint sampler
and rendering pipeline, the OWL-ViT and Grounding DINO fine-tuning
scripts, and intermediate model checkpoints are described in the paper
but are not anonymized for double-blind release here. They will be
released alongside the camera-ready version if the paper is accepted.
