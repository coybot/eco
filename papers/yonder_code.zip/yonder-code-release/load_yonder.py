"""
Minimal loader for Yonder waypoint NPZ files.

Yonder is hosted at: https://huggingface.co/datasets/astralhf/yonder
A small reviewer sample (one full scene, 50 waypoints) is at:
                       https://huggingface.co/datasets/astralhf/yonder-sample

Each NPZ holds one drone pose with 12 yaw orientations across all sensor
modalities. Keys follow the pattern <modality>_yaw<NN>, NN in {00..11}.

Modality keys (per-yaw):
    left_rgb_yaw{NN}        (480, 640, 3) uint8       stereo left RGB
    right_rgb_yaw{NN}       (480, 640, 3) uint8       stereo right RGB
    forward_depth_yaw{NN}   (480, 640)    float16     forward depth, meters
    landing_cam_yaw{NN}     (480, 640, 3) uint8       downward RGB
    up_ir_yaw{NN}           (480, 640)    uint8       upward IR
    down_ir_yaw{NN}         (480, 640)    uint8       downward IR

Per-waypoint scalars/arrays:
    lidar360                (1024, 16)    float32    360-degree LiDAR
    position                (3,)          float32    drone position, meters
    orientation             (12, 4)       float32    quaternion per yaw

Semantic segmentation lives in a sibling file under semantics/{scene}/:
    {scene}_wp{NNNN}_semantics.npz
        yaw{NN}_semantic    (480, 640)    uint16     per-pixel category IDs
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

NUM_YAWS = 12


def load_waypoint(npz_path: str | Path) -> dict:
    """Load all 12 yaws of all modalities for one waypoint NPZ."""
    npz_path = Path(npz_path)
    with np.load(npz_path) as data:
        out = {}
        for modality in (
            "left_rgb",
            "right_rgb",
            "forward_depth",
            "landing_cam",
            "up_ir",
            "down_ir",
        ):
            stack = np.stack(
                [data[f"{modality}_yaw{i:02d}"] for i in range(NUM_YAWS)],
                axis=0,
            )
            out[modality] = stack
        for k in ("lidar360", "position", "orientation"):
            if k in data:
                out[k] = data[k]
    return out


def load_semantics(sem_npz_path: str | Path) -> np.ndarray:
    """Load the (12, H, W) uint16 category-ID stack for one waypoint."""
    with np.load(sem_npz_path) as data:
        return np.stack(
            [data[f"yaw{i:02d}_semantic"] for i in range(NUM_YAWS)], axis=0
        )


def summarize(wp: dict) -> None:
    for k, v in wp.items():
        print(f"  {k:14s} shape={tuple(v.shape)} dtype={v.dtype}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("npz", help="path to a wp*.npz file")
    ap.add_argument(
        "--semantics",
        help="path to matching {scene}_wp{NNNN}_semantics.npz (optional)",
    )
    args = ap.parse_args()

    wp = load_waypoint(args.npz)
    print(f"Waypoint NPZ: {args.npz}")
    summarize(wp)

    if args.semantics:
        sem = load_semantics(args.semantics)
        print(f"\nSemantics: {args.semantics}")
        print(f"  shape={tuple(sem.shape)} dtype={sem.dtype}")
        uniq = np.unique(sem)
        print(f"  {len(uniq)} unique category IDs: {uniq.tolist()[:20]}{'...' if len(uniq) > 20 else ''}")


if __name__ == "__main__":
    main()
