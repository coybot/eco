"""
Reproduce the headline finding from the trial logs in eval_logs/.

The trial JSONLs cover four detector configurations (Grounding DINO
zero-shot vs fine-tuned, safety enabled vs disabled) crossed with three
Isaac Sim environments (warehouse, hospital, office) and 14 task
difficulty tiers. The finding is that across all four configurations,
closed-loop navigation outcomes do NOT separate -- the 9.7x offline mAP
gain from fine-tuning on Yonder does not translate to closed-loop gains.

Two success metrics are reported:

  * arrived           the per-trial boolean as recorded by the simulator
                      (uses a tight per-tier tolerance)
  * err < 5m          a softer geometric criterion: final position
                      within 5 m of ground truth

Run:    python reproduce_finding.py
"""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

LOGS_DIR = Path(__file__).parent / "eval_logs"
SOFT_THRESHOLD_M = 5.0


def load_trials_in(p: Path) -> list[dict]:
    out = []
    for jf in sorted(p.glob("*.jsonl")):
        with open(jf) as f:
            for line in f:
                line = line.strip()
                if line:
                    out.append(json.loads(line))
    return out


def summarize(label: str, trials: list[dict]) -> None:
    if not trials:
        print(f"\n[{label}] (no trials)")
        return
    by_cond = defaultdict(list)
    for t in trials:
        by_cond[t["condition"]].append(t)
    print(f"\n[{label}] {len(trials)} trials")
    print(
        f"  {'condition':<40s} {'n':>5s} {'arrived':>10s}"
        f" {'err<' + str(int(SOFT_THRESHOLD_M)) + 'm':>10s}"
        f" {'mean_err_m':>12s}"
    )
    for cond in sorted(by_cond):
        ts = by_cond[cond]
        n = len(ts)
        arrived = sum(1 for t in ts if t.get("arrived")) / n
        soft = sum(1 for t in ts if t["final_error_m"] < SOFT_THRESHOLD_M) / n
        err = sum(t["final_error_m"] for t in ts) / n
        print(
            f"  {cond:<40s} {n:>5d}"
            f" {arrived:>9.1%}"
            f" {soft:>9.1%}"
            f" {err:>12.2f}"
        )


def by_difficulty(trials: list[dict]) -> None:
    by_tier = defaultdict(list)
    for t in trials:
        by_tier[t.get("difficulty_tier", "?")].append(t)
    print("\n[by difficulty tier, all trials pooled]")
    print(
        f"  {'tier':<20s} {'n':>5s} {'arrived':>10s}"
        f" {'err<' + str(int(SOFT_THRESHOLD_M)) + 'm':>10s}"
    )
    for tier in sorted(by_tier):
        ts = by_tier[tier]
        n = len(ts)
        arrived = sum(1 for t in ts if t.get("arrived")) / n
        soft = sum(1 for t in ts if t["final_error_m"] < SOFT_THRESHOLD_M) / n
        print(f"  {tier:<20s} {n:>5d} {arrived:>9.1%} {soft:>9.1%}")


def main() -> None:
    all_trials: list[dict] = []
    for sub in sorted(p for p in LOGS_DIR.iterdir() if p.is_dir()):
        ts = load_trials_in(sub)
        summarize(sub.name, ts)
        all_trials.extend(ts)

    by_difficulty(all_trials)

    print(
        "\nKey observation: closed-loop outcomes do not separate by"
        " detector configuration -- the 9.7x offline mAP gain from"
        " fine-tuning Grounding DINO on Yonder does not translate to"
        " closed-loop navigation gains. Most failures concentrate on"
        " the harder difficulty tiers (occluded targets, multi-leg"
        " plans, obstacle avoidance), where detector quality is not"
        " the binding constraint -- 3D goal localization is."
    )


if __name__ == "__main__":
    main()
